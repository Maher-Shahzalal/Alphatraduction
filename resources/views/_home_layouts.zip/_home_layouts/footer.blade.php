<div class="row">
    <div class="col-md-12">
        <div class="copyright">
            <p>  &copy; Copyright 2021 <strong><span>{{ __('auth.ALPHA TRADUCTION') }}</span></strong> {{ __('auth.by') }}
                <strong><span> {{ __('auth.Ayachi Noor') }} . </span></strong>{{ __('auth.All Rights Reserved') }}.</p>
        </div>
    </div>
</div>
<script src="{{ url('assets/vendor/jquery-3.2.1.min.js') }}"></script>
<!-- Bootstrap JS-->
<script src="{{ url('assets/vendor/bootstrap-4.1/popper.min.js') }}"></script>
<script src="{{ url('assets/vendor/bootstrap-4.1/bootstrap.min.js') }}"></script>
<!-- Vendor JS       -->
<script src="{{ url('assets/vendor/slick/slick.min.js') }}">
</script>
<script src="{{ url('assets/vendor/wow/wow.min.js') }}"></script>
<script src="{{ url('assets/vendor/animsition/animsition.min.js') }}"></script>
<script src="{{ url('assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js') }}">
</script>
<script src="{{ url('assets/vendor/counter-up/jquery.waypoints.min.js') }}"></script>
<script src="{{ url('assets/vendor/counter-up/jquery.counterup.min.js') }}">
</script>
<script src="{{ url('assets/vendor/circle-progress/circle-progress.min.js') }}"></script>
<script src="{{ url('assets/vendor/perfect-scrollbar/perfect-scrollbar.js') }}"></script>
<script src="{{ url('assets/vendor/chartjs/Chart.bundle.min.js') }}"></script>
<script src="{{ url('assets/vendor/select2/select2.min.js') }}">
</script>

<!-- Main JS-->
<script src="{{ url('assets/js/main.js') }}"></script>

</body>

</html>
