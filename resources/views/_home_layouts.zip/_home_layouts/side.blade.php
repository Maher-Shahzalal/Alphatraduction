
<header class="header-mobile d-block d-lg-none">
    <div class="header-mobile__bar">
        <div class="container-fluid">
            <div class="header-mobile-inner">
                <a class="logo" href="#">
                    <img src="{{ url('assets/images/icon/log.png') }}" alt="Cool Admin" />
                </a>
            </div>
        </div>
    </div>

</header>



<aside class="d-none d-lg-block">
    <div class="logo">
        <img src="{{ url('assets/images/icon/log.png') }}" alt="Cool Admin" />
    </div>

</aside>
